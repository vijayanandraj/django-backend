package com.redhat.parodos.notification.enums;

/**
 * Notification state
 *
 * @author Annel Ketcha (Github: anludke)
 */

public enum State {

	ARCHIVED, UNREAD

}
