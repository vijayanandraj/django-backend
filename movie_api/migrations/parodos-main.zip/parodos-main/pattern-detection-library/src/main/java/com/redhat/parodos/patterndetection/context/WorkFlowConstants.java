/*
 * Copyright (c) 2022 Red Hat Developer
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.redhat.parodos.patterndetection.context;

/**
 * These are used to put things in the @see WorkContext - DESIRED_PATTERNS - Patterns we
 * are looking for - DETECTED_PATTERNS - As Patterns are found during scanning, they are
 * stored in the WorkContext using this key - START_DIRECTORY - Where to start scanning -
 * FILES_TO_SCAN - The files are folders contained in the START_DIRECTORY -
 * FOLDERS_TO_SCAN - All the folders contained in the START_DIRECTORY location
 *
 * These are used to both PUT and GET from Context
 *
 * @author Luke Shannon (Github: lshannon)
 *
 */
public enum WorkFlowConstants {

	DESIRED_PATTERNS, DETECTED_PATTERNS, DETECTED_CLUES, START_DIRECTORY, START_FILE, FILES_TO_SCAN, FOLDERS_TO_SCAN

}
