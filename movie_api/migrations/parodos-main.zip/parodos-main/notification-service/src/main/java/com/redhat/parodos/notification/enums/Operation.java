package com.redhat.parodos.notification.enums;

/**
 * Notification user's operation
 *
 * @author Annel Ketcha (Github: anludke)
 */
public enum Operation {

	ARCHIVE, READ

}
